# Third-Party Real Rocket League Asset Attribution

All staged 3D models and Draco decoder binaries in `assets/` are distributed under permissive **MIT** terms from the following open-source upstream packages:

## 1. `@rlrml/player@1.5.1` (MIT License)
- **Tarball Provenance**: `https://registry.npmjs.org/@rlrml/player/-/player-1.5.1.tgz`
- **License**: MIT
- **Staged Assets**:
  - `models/stadium.glb` (`package/public/models/stadium/stadium.glb`, interior playing field cage & visible field textures; external bowl removed)
  - `models/car_octane.glb` (`package/public/models/cars/octane/octane.glb`, pruned to body albedo)
  - `models/car_fennec.glb` (`package/public/models/cars/fennec/fennec.glb`, pruned to body albedo)
  - `models/car_dominus.glb` (`package/public/models/cars/dominus/dominus.glb`, pruned to body albedo)
  - `models/car_breakout.glb` (`package/public/models/cars/breakout/breakout.glb`, pruned to body albedo)
  - `models/car_plank.glb` (`package/public/models/cars/mantis/mantis.glb`, pruned to body albedo)
  - `models/car_hybrid.glb` (`package/public/models/cars/x-devil/x-devil.glb`, pruned to body albedo)
  - `models/car_merc.glb` (`package/public/models/cars/merc/merc.glb`, pruned to body albedo)
  - `models/wheel_boog.glb` (`package/public/models/wheels/Wheel_Boog.glb`, geometry only)
  - `models/ball_geodesic.glb` (packed from `package/public/models/ball/scene.gltf` + `scene.bin`, geometry only)
  - `draco/draco_decoder.js`, `draco/draco_wasm_wrapper.js`, `draco/draco_decoder.wasm`

## 2. `manucabral/rl-replay-viewer` (MIT License)
- **Repository Provenance**: `https://github.com/manucabral/rl-replay-viewer` (`https://raw.githubusercontent.com/manucabral/rl-replay-viewer/main/assets`)
- **License**: MIT
- **Staged Assets**:
  - `models/mannfield_grass.glb` (converted from ActorX `Grass_Base.pskx` + `FieldPattern_Classic_1x1.png`)
  - `models/boost_pad_big.glb` (converted from ActorX `BoostPad_Large.pskx` + `BoostPad_Large_Glow.pskx`, geometry only)
  - `models/boost_pad_small.glb` (converted from ActorX `BoostPad_Small_02_SM.pskx`, geometry only)
