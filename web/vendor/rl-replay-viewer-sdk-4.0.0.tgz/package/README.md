# @rl-replay/viewer-sdk

Zero-singleton, multi-instance embeddable 3D Rocket League replay viewer, analytics dashboard, and physics State Studio SDK (`v4.0.0`).

## Features

- **Zero Singletons & Full Multi-Embed Isolation**: Mount any number of independent viewers or `<rl-replay-viewer>` elements in the same page with Shadow DOM style adoption (`adoptViewerStyles`), focus-scoped hotkeys (`ScopedHotkeyManager`), and deterministic `dispose()` + `WEBGL_lose_context`.
- **Atomic DOM Relocation (`moveBefore`)**: `<rl-replay-viewer>` implements `connectedMoveCallback()` and microtask-guarded `disconnectedCallback()` to preserve live WebGL2 contexts and playback state across DOM reparenting.
- **RLV4 Rust/WASM Parser (`boxcars_v4`)**: Parses `.replay` files in a module worker (`./workers/ingest`) or direct `WasmReplayLoader` into a typed SoA memory layout (`SoATelemetryStore`), with Hermite interpolation and static 79-metric + PVA momentum analysis.
- **Interactive 3D Stage & PBR Arena**: Babylon.js 9 WebGL2 arena + real Rocket League `.glb` asset pack (`assets/manifest.json`), HDR/procedural IBL studio lighting, CSM shadows, ACES Filmic HDR post-processing, 6 camera modes, 3D surface telestrator, and Visual QA Showroom (`?qa=...`).
- **State Studio & 120Hz Simulation**: Undoable entity editing, 3D gizmos + surface snapping, counterfactual branching (`TimelineBranchStore`), field symmetry mirroring, scenario presets, optional Rapier 120Hz rollout (`@dimforge/rapier3d-compat`), Playbook v2.1 decks, `.rlbundle` archives, LWW CRDT collaboration, and BakkesMod / RLBot / RocketSim / NPZ / CSV / PNG / WebM exports.

## Installation

```bash
npm install @rl-replay/viewer-sdk @babylonjs/core @babylonjs/loaders fflate meshoptimizer
# Optional peer dependencies:
npm install react react-dom
npm install @dimforge/rapier3d-compat
```

Import styles (for Light DOM hosts; `<rl-replay-viewer>` adopts CSS automatically via Shadow DOM):

```ts
import '@rl-replay/viewer-sdk/styles.css';
```

## Quick Start

### 1. Imperative SDK (`createReplayViewer`)

```ts
import { createReplayViewer } from '@rl-replay/viewer-sdk';
import '@rl-replay/viewer-sdk/styles.css';

const container = document.querySelector<HTMLElement>('#viewer-mount')!;
const viewer = createReplayViewer(container, {
  profile: 'coach',
  quality: 'auto',
  assets: {
    wasmSource: './wasm/bin/rl_boxcars_v4.wasm',
    assetBaseUrl: './assets/',
  },
});

await viewer.loadReplay('./sample.replay');
viewer.play();
```

### 2. Web Component (`<rl-replay-viewer>`)

```ts
import '@rl-replay/viewer-sdk/element';
```

```html
<rl-replay-viewer
  src="./sample.replay"
  profile="coach"
  quality="auto"
  theme="champions_night"
  autoplay
></rl-replay-viewer>
```

Supports `document.querySelector('#slot').moveBefore(el, null)` with zero WebGL context rebuild.

### 3. React 18 / 19 (`RLReplayStage` / `useReplayViewer`)

```ts
import { createElement } from 'react';
import { RLReplayStage } from '@rl-replay/viewer-sdk/react';
import '@rl-replay/viewer-sdk/styles.css';

export function ReplayPanel() {
  return createElement(RLReplayStage, {
    source: './sample.replay',
    profile: 'broadcast',
    autoplay: true,
    style: { height: '640px' },
  });
}
```

## Subpath Exports

| Subpath | Description |
| --- | --- |
| `@rl-replay/viewer-sdk` | Full SDK (`RLReplayViewer`, `createReplayViewer`, `RLReplayViewerElement`, all layers) |
| `@rl-replay/viewer-sdk/core` | Pure headless WASM loader, SoA store, playback clock, math, physics, 79-metric analytics |
| `@rl-replay/viewer-sdk/studio` | `GameWorldStateStore`, branches, Rapier plugin, Playbook decks, LWW sync, codecs/exporters |
| `@rl-replay/viewer-sdk/render` | `ViewerCanvasStage`, Babylon.js 9 arena, entities, gizmos, telestrator, camera director, CSM/HDR IBL |
| `@rl-replay/viewer-sdk/ui` | HUD bar, timeline scrubber, PVA canvas, workspace rails, State Studio inspector, dialogs |
| `@rl-replay/viewer-sdk/element` | Shadow DOM `<rl-replay-viewer>` Custom Element |
| `@rl-replay/viewer-sdk/react` | StrictMode-safe React 18/19 `RLReplayStage` and `useReplayViewer` |
| `@rl-replay/viewer-sdk/workers/ingest` | Web Worker `.replay` -> RLV4 WASM ingest script |
| `@rl-replay/viewer-sdk/styles.css` | Bundled design tokens, layout, and glassmorphic panel stylesheet |

## Development, Releases & Testing

Run commands directly from the repository root:

```bash
npm ci
cargo test --manifest-path wasm/boxcars_v4/Cargo.toml
npm run build:wasm:cargo
npm run build:wasm:stage
npm run typecheck
npm run build:release
npm run build:dts
npm test
npm run test:e2e
```

See [docs/INTEGRATION_GUIDE.md](./docs/INTEGRATION_GUIDE.md) for host asset setup, `::part()` styling, headless pipelines, and interchange codecs, and [docs/adr/](./docs/adr/) for architectural contracts (`ADR-022` through `ADR-027`).
