# Changelog

All notable changes to `@rl-replay/viewer-sdk` are documented in this file.

## 4.0.0

### Architecture & Isolation
- **Zero Singletons & Multi-Embed Safe**: Removed all global mutable registries, `document.getElementById` calls, `window` resize/key listeners, and WebAudio dependencies.
- **RLV4 Binary SoA ABI**: Integrated Rust/WASM `boxcars_v4` (`rl_boxcars_v4.wasm`) emitting 64-byte aligned `RLV4` telemetry buffers directly consumed by `SoATelemetryStore`.
- **Headless Pure Core (`./core`)**: Decoupled `PlaybackClock`, `ReplayPacingEngine`, `GameStateProjector`, `StaticAnalysisEngine` (74 metrics), `PvaTemporalEngine`, and solvers cleanly from DOM/React/Three.js.

### 3D Rendering & Visual Polish (`./render`)
- Added `ViewerCanvasStage` assembling `THREE.WebGLRenderer` (`SRGBColorSpace`, `ACESFilmicToneMapping`, `1.05` exposure, `PCFSoftShadowMap`).
- Added `StudioPmremRig`, `CsmShadowRig`, `PostProcessPipeline`, and frame-time `QualityGovernor` (`auto`, `high`, `medium`, `low`).
- Shipped CC0 low-poly PBR `.glb` models (`assets/manifest.json`) with Tier-0 procedural geometry fallback (`ProceduralSoccarArena`, `ArenaBowlLoader`, `CarEntityPool`, `BallEntityRenderer`).
- Added `CameraDirector`, `VisualQaShowroomRig`, supersonic/boost/demo/goal/touch VFX, tactical Voronoi & ball trajectory overlays, and 3D surface telestrator.

### State Studio, Simulation & Packaging (`./studio`)
- Added `GameWorldStateStore` with undo/redo command history, `TimelineBranchStore` counterfactual branching, `ScenarioPresetLibrary`, and `WorldSymmetryMirror`.
- Added 120Hz `CarKinematicsSolver` / `BallPhysicsSolver` plus optional `RapierRolloutPlugin`.
- Added Playbook v2.1 (`PlaybookDeckStore`), ZIP `.rlbundle` archives (`RlBundleArchive`), and LWW CRDT sync (`LwwSyncEngine`, `WebSocketSyncTransport`).
- Added interchange & media exporters: `BakkesModExporter`, `RlBotStateCodec`, `RocketSimStateCodec`, `NpzTensorExporter`, `CsvReportExporter`, `SnapshotExporter`, and `ViewportMediaRecorder`.

### Embeds & Release Artifacts (`./element`, `./react`, Standalone)
- Added `<rl-replay-viewer>` Custom Element with Shadow DOM `adoptViewerStyles`, `::part(stage|hud|timeline|sidebar)`, `ElementInternals` states, and `connectedMoveCallback()` preservation across `Node.moveBefore()`.
- Added React 18/19 StrictMode-safe `RLReplayStage` and `useReplayViewer`.
- Added standalone web application (`src/standalone.ts`, `dist-app/`) and `scripts/build-release.mjs` producing `.tgz`, `.zip`, `SHA256SUMS.txt`, and `RELEASE_MANIFEST.json`.
